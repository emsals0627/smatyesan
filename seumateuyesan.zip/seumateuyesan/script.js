window.onload = function () {
  // 날짜 기본값 설정
  const dateInput = document.getElementById('expense-date');
  const today = new Date().toISOString().split('T')[0];
  dateInput.value = today;

  // 목표 예산 불러오기
  let goal = localStorage.getItem("goal") || "";
  document.getElementById("goal").value = goal;

  // 탭과 절약 팁 초기화
  showTab('input');
  displayTip();
};

function addExpense() {
  const amount = Number(document.getElementById("amount").value);
  const detail = document.getElementById("detail").value;
  const category = document.getElementById("category").value;
  const date = document.getElementById("expense-date").value; // ✅ 사용자가 선택한 날짜

  if (!amount || !category || !date) {
    alert("금액, 카테고리, 날짜를 모두 입력해주세요!");
    return;
  }

  let expenses = JSON.parse(localStorage.getItem(`expenses_${date}`)) || [];
  const editMode = JSON.parse(localStorage.getItem("edit_mode"));

  if (editMode && editMode.date === date) {
    expenses[editMode.index] = { amount, detail, category };
    localStorage.removeItem("edit_mode");
  } else {
    expenses.push({ amount, detail, category });
  }

  localStorage.setItem(`expenses_${date}`, JSON.stringify(expenses));
  localStorage.setItem("goal", document.getElementById("goal").value);

  resetFields();
  showHistory(); // 기록 갱신
  updateSummary(); // 요약 갱신
  renderChart(); // 차트 갱신
  renderCalendar(); // 달력도 리렌더링
}

function resetFields() {
  document.getElementById('category').value = '식비';
  document.getElementById('amount').value = '';
  document.getElementById('detail').value = '';

  // 날짜도 오늘로 초기화
  const dateInput = document.getElementById('expense-date');
  const today = new Date().toISOString().split('T')[0];
  dateInput.value = today;
}

function showTab(tabId) {
  const tabs = document.querySelectorAll(".tab-content");
  tabs.forEach(tab => {
    tab.style.display = (tab.id === tabId) ? "block" : "none";
  });

  if (tabId === 'charts') {
    const today = new Date().toISOString().slice(0, 10);
    const data = JSON.parse(localStorage.getItem(`expenses_${today}`)) || [];
    renderChart(data);
  } else if (tabId === 'history') {
    showHistory();
  }
}

function showHistory() {
  const container = document.getElementById("calendar");
  container.innerHTML = "";

  const detailContainer = document.getElementById("history-detail");
  detailContainer.innerHTML = "";

  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0부터 시작 (0 = 1월)

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDay = firstDay.getDay(); // 요일 (0 = 일요일)

  // 기록된 날짜
  const expenseKeys = Object.keys(localStorage).filter(k => k.startsWith("expenses_"));
  const recordedDates = new Set(expenseKeys.map(k => k.replace("expenses_", "")));

  const table = document.createElement("table");
  table.className = "calendar";

  const weekdays = ["일", "월", "화", "수", "목", "금", "토"];
  const headerRow = document.createElement("tr");
  weekdays.forEach(day => {
    const th = document.createElement("th");
    th.innerText = day;
    headerRow.appendChild(th);
  });
  table.appendChild(headerRow);

  let row = document.createElement("tr");
  for (let i = 0; i < startDay; i++) {
    row.appendChild(document.createElement("td"));
  }

  for (let d = 1; d <= lastDay.getDate(); d++) {
    const date = new Date(year, month, d);
    const dateStr = date.toISOString().slice(0, 10);
    const cell = document.createElement("td");
    cell.innerText = d;

    if (recordedDates.has(dateStr)) {
      cell.style.backgroundColor = "#a7e0a0"; // 지출 기록 있는 날짜 표시
      cell.style.cursor = "pointer";
      cell.onclick = () => {
        showDetailInCalendar(dateStr);
      };
    }

    row.appendChild(cell);

    if (date.getDay() === 6) {
      table.appendChild(row);
      row = document.createElement("tr");
    }
  }

  if (row.children.length > 0) {
    table.appendChild(row);
  }

  container.appendChild(table);
}

function showDetailInCalendar(date) {
  const data = JSON.parse(localStorage.getItem(`expenses_${date}`)) || [];
  const container = document.getElementById("history-detail");
  container.innerHTML = `<h3>${date} 지출 내역</h3>`;

  if (data.length === 0) {
    container.innerHTML += "<p>지출 내역이 없어요.</p>";
    return;
  }

  data.forEach((item, index) => {
    const div = document.createElement("div");
    div.innerHTML = `[${item.category}] ${item.detail} - ${item.amount.toLocaleString()}원 
      <button onclick="editExpense('${date}', ${index})">수정</button> 
      <button onclick="deleteExpense('${date}', ${index})">삭제</button>`;
    container.appendChild(div);
  });
}

function showDetail(date) {
  const data = JSON.parse(localStorage.getItem(`expenses_${date}`)) || [];
  const container = document.getElementById("history-list");
  container.innerHTML = `<h3>${date} 지출 내역</h3>`;

  data.forEach((item, index) => {
    const li = document.createElement("div");
    li.innerHTML = `[${item.category}] ${item.detail} - ${item.amount.toLocaleString()}원 
      <button onclick="editExpense('${date}', ${index})">수정</button> 
      <button onclick="deleteExpense('${date}', ${index})">삭제</button>`;
    container.appendChild(li);
  });

  const backBtn = document.createElement("button");
  backBtn.textContent = "뒤로가기";
  backBtn.onclick = showHistory;
  container.appendChild(backBtn);
}

function editExpense(date, index) {
  const data = JSON.parse(localStorage.getItem(`expenses_${date}`)) || [];
  const item = data[index];

  document.getElementById("amount").value = item.amount;
  document.getElementById("detail").value = item.detail;
  document.getElementById("category").value = item.category;

  localStorage.setItem("edit_mode", JSON.stringify({ date, index }));
  showTab("input");
}

function deleteExpense(date, index) {
  let data = JSON.parse(localStorage.getItem(`expenses_${date}`)) || [];
  if (confirm("정말 삭제할까요?")) {
    data.splice(index, 1);
    localStorage.setItem(`expenses_${date}`, JSON.stringify(data));
    showDetail(date);
  }
}

function updateSummary() {
  const summaryDiv = document.getElementById("summary");
  const feedbackDiv = document.getElementById("feedback");
  const badgeDiv = document.getElementById("badge");

  const allKeys = Object.keys(localStorage).filter(k => k.startsWith("expenses_"));
  let total = 0;
  const categoryTotals = {};

  allKeys.forEach(key => {
    const data = JSON.parse(localStorage.getItem(key));
    data.forEach(item => {
      total += item.amount;
      categoryTotals[item.category] = (categoryTotals[item.category] || 0) + item.amount;
    });
  });

  summaryDiv.innerHTML = `총 지출: ${total.toLocaleString()}원<br>` +
    Object.entries(categoryTotals).map(([cat, amt]) =>
      `${cat}: ${amt.toLocaleString()}원`).join("<br>");

  if (goal) {
    if (total <= goal) {
      feedbackDiv.innerText = "👍 목표 예산을 잘 지키고 있어요!";
      badgeDiv.innerText = "🏅 절약왕!";
    } else {
      feedbackDiv.innerText = "⚠️ 예산 초과! 다음엔 조심!";
      badgeDiv.innerText = "";
    }
  }
}

function renderChart(data) {
  const ctx = document.getElementById("expenseChart").getContext("2d");

  if (window.expenseChartInstance) {
    window.expenseChartInstance.destroy();
  }

  const categoryTotals = {};
  data.forEach(item => {
    categoryTotals[item.category] = (categoryTotals[item.category] || 0) + item.amount;
  });

  window.expenseChartInstance = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: Object.keys(categoryTotals),
      datasets: [{
        label: "지출 비율",
        data: Object.values(categoryTotals),
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#66BB6A']
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: "bottom" }
      }
    }
  });
}

function displayTip() {
  const tips = [
    "💡 오늘은 지름신을 쉬게 해보자!",
    "💡 장볼 땐 리스트 작성 꼭!",
    "💡 필요 없는 구독 해지했어?",
    "💡 카페 대신 텀블러~",
    "💡 일주일에 하루는 소비 없는 날!"
  ];
  const tip = tips[Math.floor(Math.random() * tips.length)];
  document.getElementById("tip").innerText = tip;
}